<?php
require_once 'templates/header.php';
require_once 'templates/nav.php';
require_once 'RESTful.php';
$url = 'https://www.statravel.com/blog/feed/';
$response = curl_get($url);
$xml = simplexml_load_string($response);
?>

<div class="container container-fluid px-4 py-4">
       <div class="row mt-4 ml-4">
       <div class="col">

<?php
foreach ($xml->channel->item as $item) {
echo '
<h1 class="display-4">'.$item->title.'</h1>
<p>'.$item->pubDate.'</p>
<br><hr><br>
<p>'.$item->description.'</p>
<br><hr><br>
';
}
?>

</div>

<div class="col">
<h2>Recent Posts</h2>
<p><?php
foreach ($xml->channel->item as $item) {
       echo '<a href="'.$item->link.'" target="_blank">'.$item->title.'</a><br>';
}
?><p>

</div>

</div>
</div>
</div>

<?php
require_once 'templates/footer.php';
?>

