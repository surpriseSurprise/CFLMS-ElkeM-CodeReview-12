<div class="parallax">
<?php
require_once 'templates/header.php';
require_once 'templates/nav.php';
?>

<h1 class="site-title h1f">EVEREST</h1>
<h2 class="site-description h2f">A Peak Travel Blog Theme</h2>
<!-- <img class="img-fluid everest" src="img/everest-1.jpg" alt="image"> -->
<hr class="mx-4">
</div>

<footer class="footer footer-expand-lg pt-0 py-4">
<div class="container float-left ">
<p class="pl-4">(c) Elke M., 2020<br><br></p>
 <p></p>
</div>
</footer>

<?php
require_once "templates/footer.php";
?>

          
