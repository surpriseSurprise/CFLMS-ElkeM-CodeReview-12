<?php
require_once 'templates/header.php';
require_once 'templates/nav.php';
require_once 'RESTful.php';
$url = 'https://www.statravel.com/blog/feed/';
$response = curl_get($url);
$xml = simplexml_load_string($response);
?>

<div class="container container-fluid">
<div class="row mt-4">

<?php
foreach ($xml->channel->item as $item) {
echo '<div class="col-sm-12 col-md-6 col-lg-3 pl-2 my-3">
<div class="card px-4">
<div class="card-body">
<a href="blogpost.php"<h5 class="card-title">'.$item->title.'</h5></a>
<p>'.$item->pubDate.'</p>
<p>'.$item->description.'</p>
</div>
</div>
</div>';
}
?>

</div>
</div>

<?php
require_once 'templates/footer.php';
?>